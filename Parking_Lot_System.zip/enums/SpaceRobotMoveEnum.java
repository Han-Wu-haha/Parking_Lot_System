package enums;

public interface SpaceRobotMoveEnum {

    String getMarsKey();

    String getPrintMsg();
}
