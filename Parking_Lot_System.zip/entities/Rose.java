package entities;

/**
 * @author Han Wu, whw10@student.unimelb.edu.au, 1468664
 */
public class Rose extends EntityPlant {

    public Rose(String key, String name) {
        super(key, name);
    }

}
