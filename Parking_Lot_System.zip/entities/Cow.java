package entities;

/**
 * @author Han Wu, whw10@student.unimelb.edu.au, 1468664
 */
public class Cow extends EntityEarthAnimal {

    public Cow(String key, String name) {
        super(key, name);
    }
}
