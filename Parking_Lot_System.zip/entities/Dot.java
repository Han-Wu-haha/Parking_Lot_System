package entities;

/**
 * @author Han Wu, whw10@student.unimelb.edu.au, 1468664
 */
public class Dot extends EntityNonScore {

    public Dot(String key, String name) {
        super(key,name);
    }

}
