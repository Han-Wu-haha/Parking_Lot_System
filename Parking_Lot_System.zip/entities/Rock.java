package entities;

/**
 * @author Han Wu, whw10@student.unimelb.edu.au, 1468664
 */
public class Rock extends EntityNonScore {

    public Rock(String key, String name) {
        super(key, name);
    }
}
