package entities;

/**
 * @author Han Wu, whw10@student.unimelb.edu.au, 1468664
 */
public class Eucalyptus extends EntityPlant {

    public Eucalyptus(String key, String name) {
        super(key, name);
    }

}
