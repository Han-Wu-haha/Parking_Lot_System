package entities;

/**
 * @author Han Wu, whw10@student.unimelb.edu.au, 1468664
 */
public class SpaceRover extends EntityNonScore {

    public SpaceRover(String key, String name) {
        super(key, name);
    }
}
