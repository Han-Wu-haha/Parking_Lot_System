package entities;

/**
 * @author Han Wu, whw10@student.unimelb.edu.au, 1468664
 */
public class Onion extends EntityPlant {

    public Onion(String key, String name) {
        super(key, name);
    }
}
