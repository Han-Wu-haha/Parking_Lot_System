package entities;

/**
 * @author Han Wu, whw10@student.unimelb.edu.au, 1468664
 */
public class Goat extends EntityEarthAnimal {

    public Goat(String key, String name) {
        super(key, name);

    }

}
