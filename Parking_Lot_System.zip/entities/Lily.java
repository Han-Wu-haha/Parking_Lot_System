package entities;

/**
 * @author Han Wu, whw10@student.unimelb.edu.au, 1468664
 */
public class Lily extends EntityPlant {

    public Lily(String key, String name) {
        super(key, name);
    }
}
