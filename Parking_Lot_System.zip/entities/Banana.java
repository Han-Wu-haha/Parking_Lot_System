package entities;

/**
 * @author Han Wu, whw10@student.unimelb.edu.au, 1468664
 */
public class Banana extends EntityPlant {

    public Banana(String key, String name) {
        super(key, name);
    }

}
